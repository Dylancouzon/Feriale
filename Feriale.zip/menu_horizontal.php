<ul>
	 <li class='menu_horizontal_1'>
		<a href="1"><img style='margin-top:66px; margin-left:0px' src="images/theme/defaut/menuH/texte/menu_horizontal_1_offclick.PNG" onmouseover="this.src='images/theme/defaut/menuH/texte/menu_horizontal_1_onclick.PNG';" onmouseout="this.src='images/theme/defaut/menuH/texte/menu_horizontal_1_offclick.PNG';" name="Consultez l'Armurie" /></a>
	</li>
	 <li class='menu_horizontal_2'>
		<a href="http://94.23.236.28/rentabilliweb/index.php?id_page=9"><img style='margin-top:67px; margin-left:3px' src="images/theme/defaut/menuH/texte/menu_horizontal_2_offclick.PNG" onmouseover="this.src='images/theme/defaut/menuH/texte/menu_horizontal_2_onclick.PNG';" onmouseout="this.src='images/theme/defaut/menuH/texte/menu_horizontal_2_offclick.PNG';" name="Votez pour Fériale" />test</a>
	</li>
	 <li class='menu_horizontal_3'>
		<a href="<?php echo $urlforum; ?>"><img style='margin-top:65px; margin-left:3px' src="images/theme/defaut/menuH/texte/menu_horizontal_3_offclick.PNG" onmouseover="this.src='images/theme/defaut/menuH/texte/menu_horizontal_3_onclick.PNG';" onmouseout="this.src='images/theme/defaut/menuH/texte/menu_horizontal_3_offclick.PNG';" name="Visitez notre Forum" /></a>
	</li>
	 <li class='menu_horizontal_4'>
		<a href="4"><img style='margin-top:70px; margin-left:3px' src="images/theme/defaut/menuH/texte/menu_horizontal_4_offclick.PNG" onmouseover="this.src='images/theme/defaut/menuH/texte/menu_horizontal_4_onclick.PNG';" onmouseout="this.src='images/theme/defaut/menuH/texte/menu_horizontal_4_offclick.PNG';" name="Voir les classements" /></a>
	</li>
</ul>	