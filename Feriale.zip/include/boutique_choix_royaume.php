<img src='images/theme/defaut/Chaps1.PNG' width='530px'/><br />
	<div style='width=99%; margin-left:100px;'>
<form action='index.php?id_page=110' name='<?php echo $idpvp; ?>' method='post'>
<input type='hidden' name='boutiqueR' value='<?php echo $idpvp; ?>' />
<input type='image' value='send' src='images/theme/defaut/icone/icone_boeufland.PNG' />
</form>

<form action='index.php?id_page=110' name='<?php echo $idfun; ?>' method='post'>
<input type='hidden' name='boutiqueR' value='<?php echo $idfun; ?>' />
<input type='image' value='send' src='images/theme/defaut/icone/icone_fun.PNG' />
</form>

<form action='index.php?id_page=110' name='<?php echo $idblizz; ?>' method='post'>
<input type='hidden' name='boutiqueR' value='<?php echo $idblizz; ?>' />
<input type='image' value='send' src='images/theme/defaut/icone/icone_blizzlike.PNG' />
</form>

<form action='index.php?id_page=110' name='<?php echo $idtwink60; ?>' method='post'>
<input type='hidden' name='boutiqueR' value='<?php echo $idtwink60; ?>' />
<input type='image' value='send' src='images/theme/defaut/icone/icone_twink60.PNG' />
</form>

<form action='index.php?id_page=110' name='<?php echo $idvachex; ?>' method='post'>
<input type='hidden' name='boutiqueR' value='<?php echo $idvachex; ?>' />
<input type='image' value='send' src='images/theme/defaut/icone/icone_vachex.PNG' />
</form>
</div>

<br /><img src='images/theme/defaut/Chaps2.PNG' width='530px'/><br />
<div style='width=99%; margin-left:100px;'>
<form action='index.php?id_page=101' name='<?php echo $idmjint; ?>' method='post'>
<input type='hidden' name='boutiqueR' value='<?php echo $idmjint; ?>' />
<input type='image' value='send' src='images/theme/defaut/icone/icone_mjint.PNG' />
</form>

<form action='index.php?id_page=101' name='<?php echo $idmjpro; ?>' method='post'>
<input type='hidden' name='boutiqueR' value='<?php echo $idmjpro; ?>' />
<input type='image' value='send' src='images/theme/defaut/icone/icone_mjpro.PNG' />
</form>

<form action='index.php?id_page=101' name='<?php echo $idmjres; ?>' method='post'>
<input type='hidden' name='boutiqueR' value='<?php echo $idmjres; ?>' />
<input type='image' value='send' src='images/theme/defaut/icone/icone_mjres.PNG' />
</form>
</div>