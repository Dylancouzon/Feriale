<form action="index.php" method="post">
	<div style='margin: auto; width: 600px; position: relative; left: -380px'>
		<div id='connexion_message'><img src='images/theme/defaut/connexion/connexion_au_site.PNG' style='margin-top: 0px; padding-top: 0px'/>

		</div>
		<div id='connexion_nom'><input type="text" name="compte" style='border:none; background: none; width:130px;'/>
			
		</div>
		<div id='connexion_password'><input type="password" name="password" style='border:none; background: none; width:130px;' />
			
		</div>
		<div id='connexion_validation'><input type="image" src="images/theme/defaut/connexion/ok_offclick.PNG" onmouseover="this.src='images/theme/defaut/connexion/ok_onclick.PNG';" onmouseout="this.src='images/theme/defaut/connexion/ok_offclick.PNG'"; value="S'inscrire" />
		
		</div>
	</div>
</form>