<html>

<head>
<title>Vote</title>
<meta name="generator" content="">
<script language="JavaScript">
<!--
function na_open_window(name, url, left, top, width, height, toolbar, menubar, statusbar, scrollbar, resizable)
{
  toolbar_str = toolbar ? 'yes' : 'no';
  menubar_str = menubar ? 'yes' : 'no';
  statusbar_str = statusbar ? 'yes' : 'no';
  scrollbar_str = scrollbar ? 'yes' : 'no';
  resizable_str = resizable ? 'yes' : 'no';

  cookie_str = document.cookie;
  cookie_str.toString();

  pos_start  = cookie_str.indexOf(name);
  pos_end    = cookie_str.indexOf('=', pos_start);

  cookie_name = cookie_str.substring(pos_start, pos_end);

  pos_start  = cookie_str.indexOf(name);
  pos_start  = cookie_str.indexOf('=', pos_start);
  pos_end    = cookie_str.indexOf(';', pos_start);
  
  if (pos_end <= 0) pos_end = cookie_str.length;
  cookie_val = cookie_str.substring(pos_start + 1, pos_end);
  if (cookie_name == name && cookie_val  == "done")
    return;

  window.open(url, name, 'left='+left+',top='+top+',width='+width+',height='+height+',toolbar='+toolbar_str+',menubar='+menubar_str+',status='+statusbar_str+',scrollbars='+scrollbar_str+',resizable='+resizable_str);
}

// --></script>

</head>

<body bgcolor="black" text="white" link="blue" vlink="purple" alink="red" style="text-align:center;">
<p align="center"><img src="/images/header.png" border="0"></p>
<p align="left" style="margin-left:25%;">&nbsp;</p>
<table align="center" border="0" style="text-align:center;" width="900" height="0">
    <tr>
        <td width="650">
            <p style="margin-left:0%;" align="center">Votez sur RPG-Para :</p>
        </td>
        <td width="650">
            <p style="margin-left:0%;" align="center">Votez sur Gowonda :</p>
        </td>
		<td width="650">
        <p style="margin-left:0%;" align="center"> Votez sur Topwow.fr :</p>
		</td>
    </tr>
    <tr>
        <td width="650">
                  <a href="http://www.rpg-paradize.com/?page=vote&vote=6570" target=_blank>
      <img src="http://www.rpg-paradize.com/vote.gif" border=0>
</a>
</a>
</td>
        <td width="650">
<a href='http://www.gowonda.com/vote.php?server_id=652' target='_blank'><img src='http://www.gowonda.com/vote.gif' border='0' width='90' height='60' /></a>
</td>
        <td width="650">
<a href='http://www.topwow.fr/in.php?id=2436' target='_blank'><img src='http://www.topwow.fr/bouton.gif' border='0' width='90' height='60' /></a>
</td>
    </tr>
</table><p>&nbsp;</p>
<p>&nbsp;</p>

<p align="center"><a href="http://www.feriale.fr/index.html"><font size="6">Revenir sur Feriale</font></a></p>
<br />
<br />
<br />
<br />

</body>

</html>

