<?php
header('Location: http://www.feriale.net/index.php');
?>