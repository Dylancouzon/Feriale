<div id='statut'>
	<table>
		<tr>
			<td class='statut_top'>
			</td>
		</tr>
		<tr>
			<td class='statut_middle'>
            <div id='serveur' >
            	<?php
				 $statut="on";
				?>
                <span class='nom_royaume'>Set realmlist login.feriale.net </span><br />
               	<img class='statut_serveur' src='images/theme/defaut/<?php echo $statut; ?>.PNG' />
				</div>
				<br /><br />						
		

				<div id='serveur'>
                <img class='type_royaume' src='images/theme/defaut/logo_type_0.PNG' />
                <span class='nom_royaume'>First Realm</span>

                <div style='margin-top:-2px'>
               	<img class='statut_serveur' src='images/theme/defaut/on.PNG' />
                <table width='160px' style='position:relative; left:70px; top:-18px;'>
                <tr><td width='25%'>
                <img class='logo_faction' src='images/theme/defaut/logo_alliance.PNG ' />
                 <span style='font-size: 9px; position: relative; top:-4px; left:-3px'>100</span>
                 </td><td width='30%'>
                 <img class='logo_faction' src='images/theme/defaut/logo_horde.PNG ' />

                 <span style='font-size: 9px; position: relative; top:-4px; left:-3px'>50</span>
                 </td><td width='40%'>
                 <span class='test' style='position:relative;'>
                 <img class='logo_faction' src='images/theme/defaut/logo_total.PNG' />
                 <span style='font-size: 11px; position: relative; top:-4px; left:-3px'><strong>150</strong></span>
                 </span>
                 </td>
                 </tr>
                 </table>
				</div>
                </div>
				<br />

				<div id='serveur'>
                <img class='type_royaume' src='images/theme/defaut/logo_type_1.PNG' />
                <span class='nom_royaume'>Second Realm</span>

                <div style='margin-top:-2px'>
               	<img class='statut_serveur' src='images/theme/defaut/on.PNG' />
                <table width='160px' style='position:relative; left:70px; top:-18px;'>
                <tr><td width='25%'>
                <img class='logo_faction' src='images/theme/defaut/logo_alliance.PNG ' />
                 <span style='font-size: 9px; position: relative; top:-4px; left:-3px'>100</span>
                 </td><td width='30%'>
                 <img class='logo_faction' src='images/theme/defaut/logo_horde.PNG ' />

                 <span style='font-size: 9px; position: relative; top:-4px; left:-3px'>50</span>
                 </td><td width='40%'>
                 <span class='test' style='position:relative;'>
                 <img class='logo_faction' src='images/theme/defaut/logo_total.PNG' />
                 <span style='font-size: 11px; position: relative; top:-4px; left:-3px'><strong>150</strong></span>
                 </span>
                 </td>
                 </tr>
                 </table>
				</div>
                </div>
				<br />

				<div id='serveur'>
                <img class='type_royaume' src='images/theme/defaut/logo_type_2.PNG' />
                <span class='nom_royaume'>Third Realm</span>

                <div style='margin-top:-2px'>
               	<img class='statut_serveur' src='images/theme/defaut/off.PNG' />
                <table width='160px' style='position:relative; left:70px; top:-18px;'>
                <tr><td width='25%'>
                <img class='logo_faction' src='images/theme/defaut/logo_alliance.PNG ' />
                 <span style='font-size: 9px; position: relative; top:-4px; left:-3px'>0</span>
                 </td><td width='30%'>
                 <img class='logo_faction' src='images/theme/defaut/logo_horde.PNG ' />

                 <span style='font-size: 9px; position: relative; top:-4px; left:-3px'>0</span>
                 </td><td width='40%'>
                 <span class='test' style='position:relative;'>
                 <img class='logo_faction' src='images/theme/defaut/logo_total.PNG' />
                 <span style='font-size: 11px; position: relative; top:-4px; left:-3px'><strong>0</strong></span>
                 </span>
                 </td>
                 </tr>
                 </table>
				</div>
                </div>
				<br />

				<div id='serveur'>
                <img class='type_royaume' src='images/theme/defaut/logo_type_3.PNG' />
                <span class='nom_royaume'>Fourth Realm</span>

                <div style='margin-top:-2px'>
               	<img class='statut_serveur' src='images/theme/defaut/on.PNG' />
                <table width='160px' style='position:relative; left:70px; top:-18px;'>
                <tr><td width='25%'>
                <img class='logo_faction' src='images/theme/defaut/logo_alliance.PNG ' />
                 <span style='font-size: 9px; position: relative; top:-4px; left:-3px'>27</span>
                 </td><td width='30%'>
                 <img class='logo_faction' src='images/theme/defaut/logo_horde.PNG ' />

                 <span style='font-size: 9px; position: relative; top:-4px; left:-3px'>13</span>
                 </td><td width='40%'>
                 <span class='test' style='position:relative;'>
                 <img class='logo_faction' src='images/theme/defaut/logo_total.PNG' />
                 <span style='font-size: 11px; position: relative; top:-4px; left:-3px'><strong>50</strong></span>
                 </span>
                 </td>
                 </tr>
                 </table>
				</div>
                </div>
				<br />
			</td>
		</tr>
		<tr>
			<td class='statut_footer'>
			<span class='login_royaume'>350</span>
		</td>
	</tr>
</table>
<div style='margin-bottom:0px; margin-top:15px'><a href='index.php?id_page=12'>
<img src="images/theme/defaut/boutique_offclick.PNG" onmouseover="this.src='images/theme/defaut/boutique_onclick.PNG';" onmouseout="this.src='images/theme/defaut/boutique_offclick.PNG';" name="Boutique" /></a>
</div>
</div>