    <a href='index.php?id_page=1'><div id='inscription' style='margin-left:-5px;'><img src="images/theme/defaut/inscription_offclick.PNG" onmouseover="this.src='images/theme/defaut/inscription_onclick.PNG';" onmouseout="this.src='images/theme/defaut/inscription_offclick.PNG';">
    </div></a>	
    <div style='width:250px; background-image: url("images/theme/defaut/menuG/menuG_bottom.JPG"); background-position: bottom left;'>
        <img style='margin-right:5px; width:248px'src='images/theme/defaut/menuG/menuG_top.JPG' />
        

					<div id='login1'>
			   <img style=' margin-left:10px; margin-top:3px; margin-bottom:0px;' onclick="document.getElementById('login1').style.display='none';document.getElementById('login2').style.display='';" src='images/theme/defaut/menuG/connexion.PNG'  onmouseover="this.src='images/theme/defaut/menuG/onclick_connexion.PNG';" onmouseout="this.src='images/theme/defaut/menuG/connexion.PNG';"/>
			</div> 
				<div id='login2' style='display:none; margin-bottom:5px; width:245px; font-size:11px'>
				<div id='login3'>
					<img style=' margin-left:10px; margin-top:3px; margin-bottom:0px;' onclick="document.getElementById('login1').style.display='';document.getElementById('login2').style.display='none';" src='images/theme/defaut/menuG/connexion.PNG' onmouseover="this.src='images/theme/defaut/menuG/onclick_connexion.PNG';" onmouseout="this.src='images/theme/defaut/menuG/connexion.PNG';"/>
				</div> 
				<div style='text-align:center;  margin-top: 10px;'>
					<strong>Nom de compte:</strong> 
					<input type="password" name="password" style='background: none; height:12px; width:100px;' />
				</div>
				<br />
				<div style='text-align:center; margin-top: 10px;'>
					<strong>Mot de passe:         </strong> 
					<input type="password" name="password" style='background: none; height:12px; width:100px;' />
				</div>	
				<div style='text-align:center; margin-top: 10px;'><input type="image" src="images/theme/defaut/menuG/ok_offclick.PNG" onmouseover="this.src='images/theme/defaut/menuG/ok_onclick.PNG';" onmouseout="this.src='images/theme/defaut/menuG/ok_offclick.PNG'"; value="Ce connecter" />
                	
				</div>
                <div style='text-align:center;  margin-top: 10px;'><strong><a href='index.php?id_page=74'>Mot de passe oubli&eacute; ?</a></strong></div>
			</div>  

			<img id='menu1' style=' margin-left:10px; margin-top:3px; margin-bottom:0px;' src='images/theme/defaut/menuG/boutique.PNG' onmouseover="this.src='images/theme/defaut/menuG/onclick_boutique.PNG'" onmouseout="this.src='images/theme/defaut/menuG/boutique.PNG'" />
			<img id='menu1' style=' margin-left:10px; margin-top:3px; margin-bottom:0px;'  src='images/theme/defaut/menuG/classes.PNG' onmouseover="this.src='images/theme/defaut/menuG/onclick_classes.PNG'" onmouseout="this.src='images/theme/defaut/menuG/classes.PNG'" />
            <img id='menu1' style=' margin-left:10px; margin-top:3px; margin-bottom:0px;'  src='images/theme/defaut/menuG/forum.PNG' onmouseover="this.src='images/theme/defaut/menuG/onclick_forum.PNG'" onmouseout="this.src='images/theme/defaut/menuG/forum.PNG'" />
			<img id='menu1' style=' margin-left:10px; margin-top:3px; margin-bottom:0px;'  src='images/theme/defaut/menuG/gestioncompte.PNG' onmouseover="this.src='images/theme/defaut/menuG/onclick_gestioncompte.PNG'" onmouseout="this.src='images/theme/defaut/menuG/gestioncompte.PNG'" />

        <br /><br /><br /><br />
    </div>