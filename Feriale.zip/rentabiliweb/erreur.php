<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
	<head>
		<title>Rentabiliweb - Feriale</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

				<style type="text/css">
		body
		{
		font-family:Verdana, Arial, Helvetica, sans-serif;
		background-image:url(../images/theme/defaut/fond/fond_top2.JPG);
		background-position:center;
		color:black;}	
		
		p
		{
			text-align: center;
		}

		a
		{
			text-decoration: underline;
			color: black;
		}

		a:hover
		{
			text-decoration: none;
		}

		h1
		{
			text-align: center;
		}

		h1 a
		{
			text-decoration: none;
			color: black;
		}

		h1 a:hover
		{
			text-decoration: underline;
		}
        </style>
        </script> 
	</head>

	<body>
<div style='width:1100px; margin:auto; text-align:center'>


<span style='padding-left:0px'><a style='border:none' href='http://www.feriale.fr/index.php'> <img src='../images/theme/defaut/logo_feriale_onclick.PNG'  style='border:none'/></a></span><br />	
<br />
<br />Erreur, le code est invalide ou n'est plus valable... 
<br />
<br />Le code que vous avez tent� de rentrer � un soucis et aucun point n'a �t� valid� sur votre compte:
<br />
<br />
<br />Vous avez probablement fait une erreur en rentrant votre code. 
<br />
<br />Solution : revenez sur la page rentabilliweb et retapez correctement votre code. 
<br />
<br />Si votre code ne vous � jamais �t� cr�dit�, merci de contacter rentabiliweb via le formulaire suivant: <strong><a href='http://www.rentabiliweb.com/component/ticket/form.php?page=form2&docId=89200&siteId=362983&lang=fr'>FORULAIRE</a></strong><br /><br />
<br /><br /><a href="index.php" style='text-decoration: none; font-size:1.5em'><strong>Acheter un nouveau code</strong></a><br /><br /><br />
<br /><a href='http://www.feriale.fr/index.php' style='text-decoration: none; font-size:2em'><strong>Revenir sur Feriale</strong></a>
</html>