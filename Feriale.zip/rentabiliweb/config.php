<?php
$connect = mysql_connect("127.0.0.1","sitepagerenta","4eZu1h726q8nTprG");
$db = mysql_select_db("elios_site");
$nombre = 100;
?>
