<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" >
	<head>
		<title>Paiements - Feriale.fr</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<style type="text/css">
		body
		{
		font-family:Verdana, Arial, Helvetica, sans-serif;
		background-image:url(../images/theme/defaut/fond/fond_top2.JPG);
		background-position:center;
		color:black;}	
		
		p
		{
			text-align: center;
		}

		a
		{
			text-decoration: underline;
			color: black;
		}

		a:hover
		{
			text-decoration: none;
		}

		h1
		{
			text-align: center;
		}

		h1 a
		{
			text-decoration: none;
			color: bkack;
		}

		h1 a:hover
		{
			text-decoration: underline;
		}
        </style>
        </script> 
	</head>

	<body>
<div style='width:1100px; margin:auto; text-align:center	'>


<span><a style='border:none' href='http://www.feriale.fr/index.php'> <img src='../images/theme/defaut/logo_feriale_onclick.PNG'  style='border:none'/></a></span>

		<p style='text-align: center;'><br />
Erreur, ce code � d�ja �tait cr�dit� sur un compte de notre site.<br />
<br />
Ce message peut apparaitre pour deux raisons :<br />

- Soit vous avez actualis� la page qui vous a d�j� cr�dit� vos points de votes.<br />

- Soit vous avez utiliser plusieurs fois le m�me code.<br /> </p>
<br /><br />
<a href="index.php" style='text-decoration: none; font-size:1.5em'><strong>Acheter un nouveau code</strong></a>
<br /><br />

		<h1><a href="../index.php" title="Feriale">Revenir sur Feriale</a></h1>
        </div>
	</body>
</html>